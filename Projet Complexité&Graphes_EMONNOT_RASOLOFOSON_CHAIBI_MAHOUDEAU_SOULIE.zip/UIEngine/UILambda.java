package UIEngine;

// Fonction Lambda excecutable via les boutons
public interface UILambda {
    void func() throws Exception;
}
